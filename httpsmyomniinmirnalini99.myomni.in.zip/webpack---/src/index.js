/* @flow */
/* eslint import/no-default-export: off */

import * as INTERFACE from './interface'; // eslint-disable-line import/no-namespace

export * from './interface';
export default INTERFACE;
