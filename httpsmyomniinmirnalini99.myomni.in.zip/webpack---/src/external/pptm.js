/* @flow */

import { pptmFactory } from './pptm-factory';

export const pptm = pptmFactory();
